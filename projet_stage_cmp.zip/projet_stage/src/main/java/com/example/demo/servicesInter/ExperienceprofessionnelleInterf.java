package com.example.demo.servicesInter;

import java.util.List;

import com.example.demo.entities.Experienceprofessionnelle;


public interface ExperienceprofessionnelleInterf {
	
	public Experienceprofessionnelle getExperienceprofessionnelle(Long numcondidat);
	public List<Experienceprofessionnelle> listExperienceprofessionnelle();
	public Long updateExperienceprofessionnelle(Experienceprofessionnelle experienceprofessionnelle);
	public void deleteExperienceprofessionnelleByNumcondidat(long numcondidat);
	public Experienceprofessionnelle saveExperienceprofessionnelle(Experienceprofessionnelle experienceprofessionnelle);
	public List<Experienceprofessionnelle> ExperienceprofessionnelleList();
	public void deleteExperienceprofessionnelle(Experienceprofessionnelle experienceprofessionnelle);



}
