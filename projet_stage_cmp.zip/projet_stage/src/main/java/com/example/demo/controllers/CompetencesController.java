package com.example.demo.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.entities.Centreinteret;
import com.example.demo.entities.Competences;
import com.example.demo.servicesInter.CompetencesInterf;

@Controller
@RequestMapping("/Competences")
public class CompetencesController {
	
	@Autowired
	CompetencesInterf competencesService;

	@PostMapping(value = "/addCompetences")
	public Competences addCompetences(@RequestBody Competences competences ) {
		return competencesService.saveCompetences(competences);
	}

	@GetMapping(value = "/listCompetences")
	public Iterable<Competences> list() {
		return competencesService.listCompetences();
	}
	
	@PutMapping(value="/updateCompetences/{numcondidat}")
	public Competences updateCompetences(@PathVariable("numcondidat") long numcondidat,@RequestBody Competences competences) {
		return competencesService.getCompetences(numcondidat);
	}

	@DeleteMapping(value="/deleteCompetences/{numcondidat}")
	public void delete(@PathVariable("numcondidat") long numcondidat) {
		competencesService.deleteCompetencesByNumcondidat(numcondidat);
	
	}


}
