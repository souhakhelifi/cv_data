package com.example.demo.entities;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Formation implements Serializable  {
    
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long numcondidat;
	private Date annee;
	private String diplome;
	private String ecole;
	private String ville;
	public Date getAnnee() {
		return annee;
	}
	public void setAnnee(Date annee) {
		this.annee = annee;
	}
	public String getDiplome() {
		return diplome;
	}
	public void setDiplome(String diplome) {
		this.diplome = diplome;
	}
	public String getEcole() {
		return ecole;
	}
	public void setEcole(String ecole) {
		this.ecole = ecole;
	}
	public String getVille() {
		return ville;
	}
	public void setVille(String ville) {
		this.ville = ville;
	}
	@Override
	public String toString() {
		return "formation [annee=" + annee + ", diplome=" + diplome + ", ecole=" + ecole + ", ville=" + ville + "]";
	}
	public Formation(Date annee, String diplome, String ecole, String ville) {
		super();
		this.annee = annee;
		this.diplome = diplome;
		this.ecole = ecole;
		this.ville = ville;
	}
	public Formation() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Long getNumcondidat() {
		return numcondidat;
	}
	public void setNumcondidat(Long numcondidat) {
		this.numcondidat = numcondidat;
	}
	
}
