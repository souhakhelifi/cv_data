package com.example.demo.servicesInter;

import java.util.List;
import com.example.demo.entities.Donneespersonnelles;

public interface DonneespersonnellesInterf {
	
	public Donneespersonnelles saveDonneespersonnelles(Donneespersonnelles donneespersonnelles);
	public Donneespersonnelles getDonneespersonnelles(Long numcondidat);
	public List<Donneespersonnelles> listDonneespersonnelles();
	public Long updateDonneespersonnelles(Donneespersonnelles donneespersonnelles);
	public void deleteDonneespersonnellesByNumcondidat(long numcondidat);
	public List<Donneespersonnelles> DonneespersonnellesList();
	public void deleteDonneespersonnelles(Donneespersonnelles donneespersonnelles);



}
