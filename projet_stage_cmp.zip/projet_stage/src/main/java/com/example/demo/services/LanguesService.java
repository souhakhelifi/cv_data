package com.example.demo.services;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.example.demo.entities.Langues;
import com.example.demo.repositories.LanguesRepository;
import com.example.demo.servicesInter.LanguesInterf;

@Service("languesService")
@Transactional
public class LanguesService implements LanguesInterf {
	
	@Autowired
	 private LanguesRepository languesRepository;

	@Override
	public Langues getLangues(Long numcondidat) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Langues> listFormation() {
		// TODO Auto-generated method stub
		return languesRepository.findAll();
	}

	@Override
	public Long updateLangues(Langues langues) {
		// TODO Auto-generated method stub
		Langues l = languesRepository.saveAndFlush(langues);
		return l.getNumcondidat();
	}

	@Override
	public void deleteLangues(Langues langues) {
		// TODO Auto-generated method stub
		languesRepository.delete(langues);
	}

	@Override
	public void deleteLanguesByNumcondidat(Long numcondidat) {
		// TODO Auto-generated method stub
		languesRepository.deleteById(numcondidat);
	}

	/*@Override
	public Long saveLangues(Langues langues) {
		// TODO Auto-generated method stub
		Langues l = languesRepository.saveAndFlush(langues);
		return l.getNumcondidat();
	}
*/
	@Override
	public List<Langues> LanguesList() {
		// TODO Auto-generated method stub
		return null;
	}

	
	@Override
	public Iterable<Langues> listLangues() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Langues saveLangues(Langues langues) {
		// TODO Auto-generated method stub
		return languesRepository.save(langues);
	}

}
