package com.example.demo.entities;

public enum Interet {
     
	Sport, Danse ,Théâtre, Photographie, Ecriture, Autre
}
