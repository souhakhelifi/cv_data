package com.example.demo.services;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.example.demo.entities.Competences;
import com.example.demo.repositories.CompetencesRepository;
import com.example.demo.servicesInter.CompetencesInterf;

@Service("competencesService")
@Transactional
public class CompetencesService implements CompetencesInterf {

	@Autowired
	 private CompetencesRepository competencesRepository;
	
	@Override
	public Competences saveCompetences(Competences competences) {
		// TODO Auto-generated method stub
		return competencesRepository.save(competences);
	}

	@Override
	public Competences getCompetences(Long numcondidat) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Competences> listCompetences() {
		// TODO Auto-generated method stub
		return competencesRepository.findAll();
	}

	@Override
	public Long updateCompetences(Competences competences) {
		// TODO Auto-generated method stub
		Competences c = competencesRepository.saveAndFlush(competences);
		return c.getNumcondidat();
	}

	
	@Override
	public void deleteCompetencesByNumcondidat(long numcondidat) {
		// TODO Auto-generated method stub
		competencesRepository.deleteById(numcondidat);
	}

	@Override
	public List<Competences> CompetencesList() {
		// TODO Auto-generated method stub
		return null;
	}

	

}
