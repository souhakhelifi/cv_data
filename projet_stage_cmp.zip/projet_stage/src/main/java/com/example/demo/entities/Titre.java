package com.example.demo.entities;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Titre implements Serializable {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long numcondidat;
	private String titrecv;
	public Long getNumcondidat() {
		return numcondidat;
	}
	public void setNumcondidat(Long numcondidat) {
		this.numcondidat = numcondidat;
	}
	public String getTitrecv() {
		return titrecv;
	}
	public void setTitrecv(String titrecv) {
		this.titrecv = titrecv;
	}
	@Override
	public String toString() {
		return "titre [titrecv=" + titrecv + "]";
	}
	public Titre(String titrecv) {
		super();
		this.titrecv = titrecv;
	}
	public Titre() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

}
