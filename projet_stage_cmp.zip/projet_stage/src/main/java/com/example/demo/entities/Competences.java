package com.example.demo.entities;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Competences implements Serializable {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long numcondidat;
	private String développement_Front_End;
	private String développement_back_End;
	private String Langages_de_programmation;
	private String Soft_skills;
	
	public Long getNumcondidat() {
		return numcondidat;
	}
	public void setNumcondidat(Long numcondidat) {
		this.numcondidat = numcondidat;
	}
	public String getDéveloppement_Front_End() {
		return développement_Front_End;
	}
	public void setDéveloppement_Front_End(String développement_Front_End) {
		this.développement_Front_End = développement_Front_End;
	}
	public String getDéveloppement_back_End() {
		return développement_back_End;
	}
	public void setDéveloppement_back_End(String développement_back_End) {
		this.développement_back_End = développement_back_End;
	}
	public String getLangages_de_programmation() {
		return Langages_de_programmation;
	}
	public void setLangages_de_programmation(String langages_de_programmation) {
		Langages_de_programmation = langages_de_programmation;
	}
	public String getSoft_skills() {
		return Soft_skills;
	}
	public void setSoft_skills(String soft_skills) {
		Soft_skills = soft_skills;
	}
	@Override
	public String toString() {
		return "competences [développement_Front_End=" + développement_Front_End + ", développement_back_End="
				+ développement_back_End + ", Langages_de_programmation=" + Langages_de_programmation + ", Soft_skills="
				+ Soft_skills + "]";
	}
	public Competences(String développement_Front_End, String développement_back_End, String langages_de_programmation,
			String soft_skills) {
		super();
		this.développement_Front_End = développement_Front_End;
		this.développement_back_End = développement_back_End;
		Langages_de_programmation = langages_de_programmation;
		Soft_skills = soft_skills;
	}
	public Competences() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	

}
