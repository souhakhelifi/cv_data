package com.example.demo.entities;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Experienceprofessionnelle implements Serializable {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long numcondidat;
	private Date dates;
	private String metierexercé;
	private String nomentreprise;
	private String localisation;
	private String resultatseventuels;
	
	public Date getDates() {
		return dates;
	}
	public void setDates(Date dates) {
		this.dates = dates;
	}
	public String getMetierexercé() {
		return metierexercé;
	}
	public void setMetierexercé(String metierexercé) {
		this.metierexercé = metierexercé;
	}
	public String getNomentreprise() {
		return nomentreprise;
	}
	public void setNomentreprise(String nomentreprise) {
		this.nomentreprise = nomentreprise;
	}
	public String getLocalisation() {
		return localisation;
	}
	public void setLocalisation(String localisation) {
		this.localisation = localisation;
	}
	public String getResultatseventuels() {
		return resultatseventuels;
	}
	public void setResultatseventuels(String resultatseventuels) {
		this.resultatseventuels = resultatseventuels;
	}
	@Override
	public String toString() {
		return "experienceprofessionnelle [dates=" + dates + ", metierexercé=" + metierexercé + ", nomentreprise="
				+ nomentreprise + ", localisation=" + localisation + ", resultatseventuels=" + resultatseventuels + "]";
	}
	public Experienceprofessionnelle(Date dates, String metierexercé, String nomentreprise, String localisation,
			String resultatseventuels) {
		super();
		this.dates = dates;
		this.metierexercé = metierexercé;
		this.nomentreprise = nomentreprise;
		this.localisation = localisation;
		this.resultatseventuels = resultatseventuels;
	}
	public Experienceprofessionnelle() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Long getNumcondidat() {
		return numcondidat;
	}
	public void setNumcondidat(Long numcondidat) {
		this.numcondidat = numcondidat;
	}
	
	
	

}
