package com.example.demo.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.entities.Donneespersonnelles;
import com.example.demo.entities.Experienceprofessionnelle;
import com.example.demo.servicesInter.ExperienceprofessionnelleInterf;

@Controller
@RequestMapping("/Experienceprofessionnelle")
public class ExperienceprofessionnelleController {
	
	@Autowired
	ExperienceprofessionnelleInterf experienceprofessionnelleService;

	@PostMapping(value = "/add_ep")
	public Experienceprofessionnelle addExperienceprofessionnelle(@RequestBody Experienceprofessionnelle experienceprofessionnelle ) {
		return experienceprofessionnelleService.saveExperienceprofessionnelle(experienceprofessionnelle);
	}

	@GetMapping(value = "/listExperienceprofessionnelle")
	public Iterable<Experienceprofessionnelle> list() {
		return experienceprofessionnelleService.listExperienceprofessionnelle();
	}
	
	@PutMapping(value="/updateExperienceprofessionnelle/{numcondidat}")
	public Experienceprofessionnelle updateExperienceprofessionnelle(@PathVariable("numcondidat") long numcondidat,@RequestBody Experienceprofessionnelle experienceprofessionnelle) {
		return experienceprofessionnelleService.getExperienceprofessionnelle(numcondidat);
	}

	@DeleteMapping(value="/deleteExperienceprofessionnelle/{numcondidat}")
	public void delete(@PathVariable("numcondidat") long numcondidat) {
		experienceprofessionnelleService.deleteExperienceprofessionnelleByNumcondidat(numcondidat);
	
	}


}
