package com.example.demo.entities;

public enum Langue {
	Espagnol, Anglais, Arabe, Français, Italien, Autre

}
