package com.example.demo.services;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.example.demo.entities.Experienceprofessionnelle;
import com.example.demo.repositories.ExperienceprofessionnelleRepository;
import com.example.demo.servicesInter.ExperienceprofessionnelleInterf;

@Service("experienceprofessionnellesService")
@Transactional
public class ExperienceprofessionnellesService implements ExperienceprofessionnelleInterf{
	

	@Autowired
	 private ExperienceprofessionnelleRepository experienceprofessionnellesRepository;

	@Override
	public Experienceprofessionnelle saveExperienceprofessionnelle(Experienceprofessionnelle experienceprofessionnelle) {
		// TODO Auto-generated method stub
		return experienceprofessionnellesRepository.save(experienceprofessionnelle);
	}

	@Override
	public Experienceprofessionnelle getExperienceprofessionnelle(Long numcondidat) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Experienceprofessionnelle> listExperienceprofessionnelle() {
		// TODO Auto-generated method stub
		return experienceprofessionnellesRepository.findAll();
	}

	@Override
	public Long updateExperienceprofessionnelle(Experienceprofessionnelle experienceprofessionnelle) {
		// TODO Auto-generated method stub
		Experienceprofessionnelle e = experienceprofessionnellesRepository.saveAndFlush(experienceprofessionnelle);
		return e.getNumcondidat();
	}

	@Override
	public void deleteExperienceprofessionnelle(Experienceprofessionnelle experienceprofessionnelle) {
		// TODO Auto-generated method stub
		experienceprofessionnellesRepository.delete(experienceprofessionnelle);
	}

	@Override
	public void deleteExperienceprofessionnelleByNumcondidat(long numcondidat) {
		// TODO Auto-generated method stub
		experienceprofessionnellesRepository.deleteById(numcondidat);
	}

	@Override
	public List<Experienceprofessionnelle> ExperienceprofessionnelleList() {
		// TODO Auto-generated method stub
		return null;
	}

	/*@Override
	public Long saveExperienceprofessionnelle(Experienceprofessionnelle experienceprofessionnelle) {
		// TODO Auto-generated method stub
		Experienceprofessionnelle e = experienceprofessionnellesRepository.saveAndFlush(experienceprofessionnelle);
		return e.getNumcondidat();
	}
*/
}
