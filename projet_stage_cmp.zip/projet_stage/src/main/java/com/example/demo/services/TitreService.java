package com.example.demo.services;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.entities.Langues;
import com.example.demo.entities.Titre;
import com.example.demo.repositories.TitreRepository;
import com.example.demo.servicesInter.TitreInterf;

@Service("titreService")
@Transactional
public class TitreService implements TitreInterf{
	
	@Autowired
	 private TitreRepository titreRepository;

	@Override
	public Titre saveTitre(Titre titre) {
		// TODO Auto-generated method stub
		return titreRepository.save(titre);
	}

	@Override
	public Titre getTitre(Long numcondidat) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Titre> listTitre() {
		// TODO Auto-generated method stub
		return titreRepository.findAll();
	}

	@Override
	public Long updateTitre(Titre titre) {
		// TODO Auto-generated method stub
		Titre t = titreRepository.saveAndFlush(titre);
		return t.getNumcondidat();
	}

	@Override
	public void deleteTitre(Titre titre) {
		// TODO Auto-generated method stub
		titreRepository.delete(titre);
	}

	@Override
	public List<Langues> TitreList() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteTitreByNumcondidat(long numcondidat) {
		// TODO Auto-generated method stub
		titreRepository.deleteById(numcondidat);
	}

}
