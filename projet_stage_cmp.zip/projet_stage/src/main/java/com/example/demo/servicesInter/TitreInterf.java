package com.example.demo.servicesInter;

import java.util.List;

import com.example.demo.entities.Langues;
import com.example.demo.entities.Titre;

public interface TitreInterf {
	
	public Titre saveTitre(Titre titre);
	public Titre getTitre(Long numcondidat);
	public List<Titre> listTitre();
	public Long updateTitre(Titre titre);
	public void deleteTitre(Titre titre);
	public List<Langues> TitreList();
	public void deleteTitreByNumcondidat(long numcondidat);


}
