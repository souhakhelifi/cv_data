package com.example.demo.entities;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Donneespersonnelles implements Serializable {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long numcondidat;
	private String nom;
	private String prenom;
	private String adresse;
	private int numtelf;
	private String email;
	private Date datedenaissance;
	private String lieudenaissance;
	private String situationfamiliale;
	
	
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public String getPrenom() {
		return prenom;
	}
	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}
	public String getAdresse() {
		return adresse;
	}
	public void setAdresse(String adresse) {
		this.adresse = adresse;
	}
	public int getNumtelf() {
		return numtelf;
	}
	public void setNumtelf(int numtelf) {
		this.numtelf = numtelf;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Date getDatedenaissance() {
		return datedenaissance;
	}
	public void setDatedenaissance(Date datedenaissance) {
		this.datedenaissance = datedenaissance;
	}
	public String getLieudenaissance() {
		return lieudenaissance;
	}
	public void setLieudenaissance(String lieudenaissance) {
		this.lieudenaissance = lieudenaissance;
	}
	public String getSituationfamiliale() {
		return situationfamiliale;
	}
	public void setSituationfamiliale(String situationfamiliale) {
		this.situationfamiliale = situationfamiliale;
	}
	public Donneespersonnelles(String nom, String prenom, String adresse, int numtelf, String email,
			Date datedenaissance, String lieudenaissance, String situationfamiliale) {
		super();
		this.nom = nom;
		this.prenom = prenom;
		this.adresse = adresse;
		this.numtelf = numtelf;
		this.email = email;
		this.datedenaissance = datedenaissance;
		this.lieudenaissance = lieudenaissance;
		this.situationfamiliale = situationfamiliale;
	}
	public Donneespersonnelles() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "donneespersonnelles [nom=" + nom + ", prenom=" + prenom + ", adresse=" + adresse + ", numtelf="
				+ numtelf + ", email=" + email + ", datedenaissance=" + datedenaissance + ", lieudenaissance="
				+ lieudenaissance + ", situationfamiliale=" + situationfamiliale + "]";
	}
	public Long getNumcondidat() {
		return numcondidat;
	}
	public void setNumcondidat(Long numcondidat) {
		this.numcondidat = numcondidat;
	}
	
	

}
