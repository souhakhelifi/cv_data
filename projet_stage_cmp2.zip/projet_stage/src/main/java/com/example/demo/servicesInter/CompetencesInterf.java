package com.example.demo.servicesInter;

import java.util.List;
import com.example.demo.entities.Competences;

public interface CompetencesInterf {
	
	public Competences saveCompetences(Competences competences);
	public Competences getCompetences(Long numcondidat);
	public List<Competences> listCompetences();
	public Long updateCompetences(Competences competences);
	public void deleteCompetencesByNumcondidat(long numcondidat);
	public List<Competences> CompetencesList();
	public Competences updateComp(long numcondidat ,Competences competences);


}
