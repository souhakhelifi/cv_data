package com.example.demo.entities;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Langues  implements Serializable{

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long numcondidat;
	@Enumerated(EnumType.STRING)
	private Langue langues;

	public Langue getLangues() {
		return langues;
	}

	public void setLangues(Langue langues) {
		this.langues = langues;
	}

	public Long getNumcondidat() {
		return numcondidat;
	}

	public void setNumcondidat(Long numcondidat) {
		this.numcondidat = numcondidat;
	}

	@Override
	public String toString() {
		return "langues [langues=" + langues + "]";
	}

	public Langues() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Langues(Langue langues) {
		super();
		this.langues = langues;
	}
	
	
}
