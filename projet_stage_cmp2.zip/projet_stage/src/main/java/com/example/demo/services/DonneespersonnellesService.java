package com.example.demo.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.example.demo.entities.Donneespersonnelles;
import com.example.demo.repositories.DonneespersonnellesRepository;
import com.example.demo.servicesInter.DonneespersonnellesInterf;

@Service("donneespersonnellesService")
@Transactional
public class DonneespersonnellesService implements DonneespersonnellesInterf {
	
	@Autowired
	private DonneespersonnellesRepository donneespersonnellesRepository;

	@Override
	public Donneespersonnelles saveDonneespersonnelles(Donneespersonnelles donneespersonnelles) {
		// TODO Auto-generated method stub
		return donneespersonnellesRepository.save(donneespersonnelles);
	}

	@Override
	public Donneespersonnelles getDonneespersonnelles(Long numcondidat) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Donneespersonnelles> listDonneespersonnelles() {
		// TODO Auto-generated method stub
		return donneespersonnellesRepository.findAll();
	}

	@Override
	public Long updateDonneespersonnelles(Donneespersonnelles donneespersonnelles) {
		// TODO Auto-generated method stub
		Donneespersonnelles d = donneespersonnellesRepository.saveAndFlush(donneespersonnelles);
		return d.getNumcondidat();
	}

	@Override
	public void deleteDonneespersonnelles(Donneespersonnelles donneespersonnelles) {
		// TODO Auto-generated method stub
		donneespersonnellesRepository.delete(donneespersonnelles);
	}

	@Override
	public void deleteDonneespersonnellesByNumcondidat(long numcondidat) {
		// TODO Auto-generated method stub
		donneespersonnellesRepository.deleteById(numcondidat);
	}

	@Override
	public List<Donneespersonnelles> DonneespersonnellesList() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Donneespersonnelles updateDp(long numcondidat, Donneespersonnelles donneespersonnelles) {
		// TODO Auto-generated method stub
		if (donneespersonnellesRepository.findById(numcondidat).isPresent()) {
			Donneespersonnelles dp = donneespersonnellesRepository.findById(numcondidat).get();
			
			dp.setAdresse(donneespersonnelles.getAdresse());
			dp.setDatedenaissance(donneespersonnelles.getDatedenaissance());
			dp.setEmail(donneespersonnelles.getEmail());
			dp.setLieudenaissance(donneespersonnelles.getLieudenaissance());
			dp.setNom(donneespersonnelles.getNom());
			dp.setPrenom(donneespersonnelles.getPrenom());
			dp.setNumtelf(donneespersonnelles.getNumtelf());
			dp.setSituationfamiliale(donneespersonnelles.getSituationfamiliale());
			
			Donneespersonnelles updateddonneespersonnelles = donneespersonnellesRepository.save(dp);
			
			return updateddonneespersonnelles;
		}
		else {
			return null;
		}
	}

}
