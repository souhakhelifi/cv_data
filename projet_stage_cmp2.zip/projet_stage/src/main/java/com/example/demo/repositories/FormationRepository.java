package com.example.demo.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.example.demo.entities.Formation;

@Repository("formationRepository")
public interface FormationRepository extends JpaRepository<Formation,Long> {
	
	public List<Formation> findByNumcondidat(Long numcondidat);

	public void deleteByNumcondidat(Long numcondidat);
	

}
