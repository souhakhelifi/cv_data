package com.example.demo.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.entities.Centreinteret;
import com.example.demo.repositories.CentreinteretRepository;
import com.example.demo.servicesInter.CentreinteretInterf;

@Service("centreinteretService")
@Transactional
public class CentreinteretService implements CentreinteretInterf {
	
	@Autowired
	 private CentreinteretRepository centreinteretRepository;

	@Override
	public Centreinteret saveCentreinteret(Centreinteret centreinteret) {
		// TODO Auto-generated method stub
		return centreinteretRepository.save(centreinteret);
	}

	@Override
	public Centreinteret getCentreinteret(Long numcondidat) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Centreinteret> listCentreinteret() {
		// TODO Auto-generated method stub
		return centreinteretRepository.findAll();
	}

	@Override
	public Long updateCentreinteret(Centreinteret centreinteret) {
		// TODO Auto-generated method stub
		Centreinteret c = centreinteretRepository.saveAndFlush(centreinteret);
		return c.getNumcondidat();
	}


	@Override
	public List<Centreinteret> CentreinteretList() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteCentreinteretByNumcondidat(long numcondidat) {
		// TODO Auto-generated method stub
		centreinteretRepository.deleteById(numcondidat);
	}

	@Override
	public void deleteCentreinteret(Centreinteret centreinteret) {
		// TODO Auto-generated method stub
		centreinteretRepository.delete(centreinteret);
		
	}

	@Override
	public Centreinteret updateCi(long numcondidat, Centreinteret centreinteret) {
		// TODO Auto-generated method stub
		if (centreinteretRepository.findById(numcondidat).isPresent()) {
			Centreinteret ci = centreinteretRepository.findById(numcondidat).get();
			
			ci.setInteret(centreinteret.getInteret());
			
			Centreinteret updatedcentreinteret = centreinteretRepository.save(ci);
			
			return updatedcentreinteret;
		}
		else {
			return null;
		}
		
	}

	

}
