package com.example.demo.servicesInter;

import java.util.List;

import com.example.demo.entities.Centreinteret;

public interface CentreinteretInterf {
	
	public Centreinteret saveCentreinteret(Centreinteret centreinteret);
	public Centreinteret getCentreinteret(Long numcondidat);
	public List<Centreinteret> listCentreinteret();
	public Long updateCentreinteret(Centreinteret centreinteret);
	public void deleteCentreinteretByNumcondidat(long numcondidat);
	public List<Centreinteret> CentreinteretList();
	void deleteCentreinteret(Centreinteret centreinteret);
	public Centreinteret updateCi(long numcondidat ,Centreinteret centreinteret);



}
