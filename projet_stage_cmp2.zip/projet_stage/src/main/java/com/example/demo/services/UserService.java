package com.example.demo.services;

import org.springframework.security.core.userdetails.UserDetailsService;

import com.example.demo.entities.User;
import com.example.demo.web.dto.UserRegistrationDto;

public interface UserService extends UserDetailsService{
	User findByEmail(String email);

    User save(UserRegistrationDto registration);
}
