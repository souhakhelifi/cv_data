package com.example.demo.servicesInter;

import java.util.List;
import com.example.demo.entities.Langues;

public interface LanguesInterf {
	
	public Langues getLangues(Long numcondidat);
	public List<Langues> listFormation();
	public Long updateLangues(Langues langues);
	public void deleteLangues(Langues langues);
	public void deleteLanguesByNumcondidat(Long numcondidat);
	public Langues saveLangues(Langues langues);
	public List<Langues> LanguesList();
	public Iterable<Langues> listLangues();
    public Langues updateLangues(long numcondidat,Langues langues);


}
