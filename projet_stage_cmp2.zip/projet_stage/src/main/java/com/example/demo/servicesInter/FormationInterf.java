package com.example.demo.servicesInter;

import java.util.List;
import com.example.demo.entities.Formation;


public interface FormationInterf {
	
	public Formation saveDonneespersonnelles(Formation formation);
	public Formation getFormation(Long numcondidat);
	public List<Formation> listFormation();
	public Long updateFormation(Formation formation);
	public void deleteFormationByNumcondidat(long numcondidat);
	public Formation saveFormation(Formation formation);
	public List<Formation> FormationList();
	public void deleteFormation(Formation Formation);
	public Formation updateFormation(long numcondidat ,Formation formation);


}
