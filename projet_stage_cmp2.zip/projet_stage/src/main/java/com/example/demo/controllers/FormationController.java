package com.example.demo.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import com.example.demo.entities.Formation;
import com.example.demo.servicesInter.FormationInterf;

@Controller
@RequestMapping("/Formation")
public class FormationController {
	
	@Autowired
	FormationInterf formationService;

	@PostMapping(value = "/addFormation")
	public Formation addFormation(@RequestBody Formation formation ) {
		return formationService.saveFormation(formation);
	}

	@GetMapping(value = "/listFormation")
	public Iterable<Formation> list() {
		return formationService.listFormation();
	}
	
	@PutMapping(value="/updateFormation/{numcondidat}")
	public Formation updateFormation(@PathVariable("numcondidat") long numcondidat,@RequestBody Formation formation) {
		return formationService.updateFormation(numcondidat,formation);
	}

	@DeleteMapping(value="/deleteFormation/{numcondidat}")
	public void delete(@PathVariable("numcondidat") long numcondidat) {
		formationService.deleteFormationByNumcondidat(numcondidat);
	
	}

}
