package com.example.demo.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import com.example.demo.entities.Langues;
import com.example.demo.servicesInter.LanguesInterf;

@Controller
@RequestMapping("/Langues")
public class LanguesController {

	@Autowired
	LanguesInterf languesService;

	@PostMapping(value = "/addLangues")
	public Langues addLangues(@RequestBody Langues langues ) {
		return languesService.saveLangues(langues);
	}

	@GetMapping(value = "/listLangues")
	public Iterable<Langues> list() {
		return languesService.listLangues();
	}
	
	@PutMapping(value="/updateLangues/{numcondidat}")
	public Langues updateLangues(@PathVariable("numcondidat") long numcondidat,@RequestBody Langues langues) {
		return languesService.updateLangues(numcondidat,langues);
	}

	@DeleteMapping(value="/deleteLangues/{numcondidat}")
	public void delete(@PathVariable("numcondidat") long numcondidat) {
		languesService.deleteLanguesByNumcondidat(numcondidat);
	
	}

}
