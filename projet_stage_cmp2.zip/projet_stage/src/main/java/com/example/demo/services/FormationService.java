package com.example.demo.services;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.example.demo.entities.Formation;
import com.example.demo.repositories.FormationRepository;
import com.example.demo.servicesInter.FormationInterf;

@Service("formationService")
@Transactional
public class FormationService implements FormationInterf {
	
	@Autowired
	 private FormationRepository formationRepository;
	
	@Override
	public Formation saveDonneespersonnelles(Formation formation) {
		// TODO Auto-generated method stub
		return formationRepository.save(formation);
	}

	@Override
	public Formation getFormation(Long numcondidat) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Formation> listFormation() {
		// TODO Auto-generated method stub
		return formationRepository.findAll();
	}

	@Override
	public Long updateFormation(Formation formation) {
		// TODO Auto-generated method stub
		Formation f = formationRepository.saveAndFlush(formation);
		return f.getNumcondidat();
	}

	@Override
	public void deleteFormation(Formation formation) {
		// TODO Auto-generated method stub
		formationRepository.delete(formation);
	}

	@Override
	public void deleteFormationByNumcondidat(long numcondidat) {
		// TODO Auto-generated method stub
		formationRepository.deleteById(numcondidat);
	}

	/*@Override
	public Long saveFormation(Formation formation) {
		// TODO Auto-generated method stub
		Formation f = formationRepository.saveAndFlush(formation);
		return f.getNumcondidat();
	}*/

	@Override
	public List<Formation> FormationList() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Formation saveFormation(Formation formation) {
		// TODO Auto-generated method stub
		return formationRepository.save(formation);
	}

	@Override
	public Formation updateFormation(long numcondidat, Formation formation) {
		// TODO Auto-generated method stub
		if (formationRepository.findById(numcondidat).isPresent()) {
			Formation fr= formationRepository.findById(numcondidat).get();
			
			fr.setAnnee(formation.getAnnee());
			fr.setDiplome(formation.getDiplome());
			fr.setEcole(formation.getEcole());
			fr.setVille(formation.getVille());
			
			Formation updatedformation = formationRepository.save(fr);
			
			return updatedformation;
		}
		else {
			return null;
		}
	}

}
