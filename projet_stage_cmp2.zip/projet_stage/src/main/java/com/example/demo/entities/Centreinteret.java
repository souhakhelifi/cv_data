package com.example.demo.entities;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Centreinteret  implements Serializable{
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long numcondidat;
	@Enumerated(EnumType.STRING)
	private Interet interet;
	public Long getNumcondidat() {
		return numcondidat;
	}
	public void setNumcondidat(Long numcondidat) {
		this.numcondidat = numcondidat;
	}
	public Interet getInteret() {
		return interet;
	}
	public void setInteret(Interet interet) {
		this.interet = interet;
	}
	@Override
	public String toString() {
		return "centreinteret [interet=" + interet + "]";
	}
	public Centreinteret(Interet interet) {
		super();
		this.interet = interet;
	}
	public Centreinteret() {
		super();
		// TODO Auto-generated constructor stub
	}

	
}
