package com.example.demo.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.example.demo.entities.Donneespersonnelles;

@Repository("donneespersonnellesRepository")
public interface DonneespersonnellesRepository extends JpaRepository<Donneespersonnelles,Long> {
	
	public List<Donneespersonnelles> findByNumcondidat(Long numcondidat);

	public void deleteByNumcondidat(Long numcondidat);
	
	public List<Donneespersonnelles> findByNomContains(String partOfNom);


}
