package com.example.demo.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.example.demo.entities.Titre;

@Repository("titreRepository")
public interface TitreRepository extends JpaRepository<Titre,Long> {
	
	public List<Titre> findByNumcondidat(Long numcondidat);

	public void deleteByNumcondidat(Long numcondidat);
	

}
